/**
 ******************************************************************************
 * @file    test.h
 * @author  Tim Behrens, Nishan Khatiwada
 * @brief   Aufgabe 2
 *          Tests for the program
 * @date    November 2026
 ******************************************************************************
 */